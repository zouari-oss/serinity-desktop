package com.serinity.exercicecontrol.service;

public class SessionStateException extends RuntimeException {
    public SessionStateException(String message) {
        super(message);
    }
}